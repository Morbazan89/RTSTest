using UnityEngine;
using System.Collections;

public class Map : MonoBehaviour 
{
	public float width = 100;
	public float height = 100;
}
