﻿using UnityEngine;
using System.Collections;

public class Navigation : MonoBehaviour 
{
	public Map MapObject;
	public float DragSpeed = 10;

	private Vector3 offsetMousePosition = Vector3.zero;
	bool Drag = false;

	private void LateUpdate()
	{
		if( Input.GetMouseButton( 0 ) )
			Drag = true;
		else
			Drag = false;

		if( Drag && UIElements.prevNumPanels == 0 )
		{

			Transform camera = CustomCamera.main.transform;
			Vector3 currMousePosition = YToZ(Input.mousePosition);
			Vector3 moveDir =  (currMousePosition - offsetMousePosition).normalized;
			camera.position -= moveDir * Time.deltaTime * DragSpeed;
			camera.position  = KeepMapLimits(camera.position);
			offsetMousePosition = currMousePosition;
		}

	}
	


	private Vector3 KeepMapLimits( Vector3 point )
	{
		
		if( point.x > MapObject.width * .5f )point.x = MapObject.width * .5f;
		else if( point.x < -MapObject.width * .5f )point.x = -MapObject.width * .5f;
		if( point.z > MapObject.height * .5f )point.z = MapObject.height * .5f;
		else if( point.z < -MapObject.height * .5f )point.z = -MapObject.height * .5f;
		
		return point;
		
	}
	Vector3 YToZ(Vector3 point ){ Vector3 tmp = Vector3.zero; tmp.x = point.x; tmp.z = point.y; return tmp;}
}
