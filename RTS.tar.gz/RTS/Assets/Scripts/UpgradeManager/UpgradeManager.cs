using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class UpgradeManager : MonoBehaviour 
{
	public List<UpgradeRequirements> upgrades;
	public static List<UpgradeRequirements> Upgrades = new List<UpgradeRequirements>();

	private void Awake()
	{
		foreach( UpgradeRequirements u in upgrades )Upgrades.Add( u );
	}
}
