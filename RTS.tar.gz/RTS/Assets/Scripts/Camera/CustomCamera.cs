﻿using UnityEngine;
using System.Collections;

public class CustomCamera : MonoBehaviour {
	

	public static Camera main;
	// Use this for initialization
	void Start ()
	{
		main = GetComponent<Camera>();
	}

}
