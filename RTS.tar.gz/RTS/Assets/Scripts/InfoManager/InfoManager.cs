using UnityEngine;
using System.Collections;
using UnityEngine.UI;


public class InfoManager: MonoBehaviour 
{

	public Button ok;
	public RectTransform panel;
	public Text msg;

	public static Text Msg;
	public static RectTransform Panel;
	public static Button Ok;
	private static float delay;
	void Start()
	{
		Msg = msg;
		Panel = panel;
		Ok = ok;
		delay = 10;
	}
	public static void NewInfo( string text, float d = 1 )
	{
		Panel.gameObject.SetActive(true);
		Msg.text = text;
		delay = d;
	}
	public void ConfirmInfo()
	{

		panel.gameObject.SetActive( false );

	}

	private void Update()
	{

		if( delay > 0 )
		{
			delay -= Time.deltaTime;
			if( delay <= 0 )
				panel.gameObject.SetActive( false );
		}

	}

	
}
