using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class UpgradeRequirements : MonoBehaviour 
{
	public List<int> UpgradeCost;
	public List<int> UnitCost;
	public GameObject UnitPrefab;

	
	public bool CanUpgrade()
	{
		int NotEnough = 0;
		for( int r=0; r != UpgradeCost.Count; r++ )
		{
			if( UpgradeCost[r] > ResourcesManager.ResourcesAmount[ r ] )NotEnough++;
		}
		return NotEnough == 0;
	}

	public bool CanSpawn()
	{
		int NotEnough = 0;
		for( int r=0; r != UnitCost.Count; r++ )
		{
			if( UnitCost[r] > ResourcesManager.ResourcesAmount[ r ] )NotEnough++;
		}
		return NotEnough == 0;
	}
}
