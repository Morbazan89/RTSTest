using UnityEngine;
using System.Collections;
using UnityEngine.UI;


public class BuildingInteraction: InteractionPanel 
{
	public Text SpawnRequest;
	public Text UpgradeRequest;

	public void HandleUpgrade()
	{

		target.GetComponent<Building>().Upgrade();

	}
	public void HandleUnitSpawn()
	{
		Building building = target.GetComponent<Building>();

		building.SpawnUnit();

	}

	void Update()
	{
		Building building = target.GetComponent<Building>();


		CountPanels();

		SpawnRequest.text = ResourcesManager.ConvertRequestToText( building.up.UnitCost );
		UpgradeRequest.text = ResourcesManager.ConvertRequestToText( building.up.UpgradeCost );
	}

}
