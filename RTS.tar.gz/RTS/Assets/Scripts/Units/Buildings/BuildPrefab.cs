using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;


public class BuildPrefab : MonoBehaviour 
{
	public GameObject Prefab;

	public List<int> BuildRequirements;

	public string BuildDescription;
	
	public Text Requirements;


	private void Update()
	{

		if(ResourcesManager.CanConsume(BuildRequirements))
			Requirements.color = Color.green;
		else
			Requirements.color = Color.red;

	}
	private void Start()
	{

		Button b = GetComponent<Button>();
		b.onClick.AddListener( HandleBuild );

		Requirements.text = ResourcesManager.ConvertRequestToText( BuildRequirements );

	}
	public void HandleBuild()
	{
		if( ResourcesManager.CanConsume( BuildRequirements ) )
		{

		GameObject obj = (GameObject)Instantiate( Prefab );

		obj.transform.position = UnitsInteraction.Selected.transform.position;
		
		ResourcesManager.AllBuildings.Add (obj.GetComponent<Building>());

		}
		
	}
}
