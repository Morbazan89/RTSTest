﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Building : Unit 
{
	public int ResouceId = 0;
	public Transform SpawnPoint;
	public UpgradeRequirements up;
	
	void Start()
	{
		up = UpgradeManager.Upgrades[Level-1];
	}
	public void SpawnUnit()
	{
		if( !up.CanSpawn() )
		{
			InfoManager.NewInfo("not enought resources to spawn this unit ", 2 );
			return;
		}

		ResourcesManager.Consume( up.UnitCost );

		GameObject obj = (GameObject)GameObject.Instantiate( up.UnitPrefab );

		obj.transform.position = SpawnPoint.position;

		obj.GetComponent<Worker>().ResourceId = ResouceId;
	}

	public void Upgrade()
	{
		if( Level == UpgradeManager.Upgrades.Count )
		{
			InfoManager.NewInfo ("max level reached",2);
			return;
		}

		if( !up.CanUpgrade() )
		{
			InfoManager.NewInfo ("cant upgrade",1);
			return;
		}
		Level++;

		InfoManager.NewInfo(name + "Upgraded to Level " + Level, 2 );

		UpgradeRequirements u = UpgradeManager.Upgrades[ Level ];

		up = u;

	}

}
