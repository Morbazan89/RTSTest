using UnityEngine;
using System.Collections;



public class ResourceUnit : Unit 
{
	public int ResourceId = 0;
	
}
