﻿using UnityEngine;
using System.Collections;

public class Worker: AnimatedUnit 
{
	public int MaxCarry = 10;
	public int cary = 0;
	public int ResourceId = 0;
	
	public float ExplicitTaskTimer = 3;

	public Unit target;
	public NavMeshAgent NavAgent;

	void Start()
	{
		ResetAnimation(0);
		FindNearestResource();
	}

	void FindNearestResource()
	{
		//print (name + " finding resource");
		target = null;
		float minDist = 999999;
		foreach( ResourceUnit r in ResourcesManager.AllResourceUnits )
		{
			if( r.ResourceId != ResourceId )continue;

			Vector3 dir = r.transform.position - transform.position;

			if( dir.sqrMagnitude < minDist )
			{minDist = dir.sqrMagnitude; target = r; }
		}

		if( target != null )
		{
			ResetAnimation(1);
			NavAgent.SetDestination( target.transform.position );
		}

	}

	void FindNearestBuilding()
	{
		target = null;
		float minDist = 999999;

		foreach( Building b in ResourcesManager.AllBuildings )
		{
			if( b.ResouceId != ResourceId )continue;

			Vector3 dir = b.transform.position - transform.position;
			
			if( dir.sqrMagnitude < minDist )
			{minDist = dir.sqrMagnitude; target = b; }
		}

		if( target != null )
		{
			ResetAnimation(1);
			NavAgent.SetDestination( target.transform.position );
		}

		NavAgent.SetDestination( target.transform.position );
	}

	private void ExplicitTask()
	{
		if( UnitsInteraction.Selected == this && Input.GetMouseButtonUp(1) )
		{
			SelectionTime = Time.fixedTime;
			Ray r = CustomCamera.main.ScreenPointToRay( Input.mousePosition );
			RaycastHit info = new RaycastHit();
			if( Physics.Raycast( r, out info ) )
			{
				//print ( info.point + " " + info.transform.name );
				NavAgent.SetDestination( info.point );
				ResetAnimation(1);
				target = null;
			}
		}
	}

	void Update()
	{
		UpdateAnimations();

		animator.SetFloat("velocity",NavAgent.velocity.magnitude );

		if( ( Time.fixedTime - SelectionTime ) < ExplicitTaskTimer )
		{
			//print ( "fixedTime " + Time.fixedTime + " delta " + (Time.fixedTime - SelectionTime ) );
			ExplicitTask();
			return;
		}

		//print ( Atention );

		if( Atention > 0 )return;

		if( target == null || cary != 0 )
			FindNearestBuilding();
		else
			FindNearestResource();



		//print (NavAgent.remainingDistance + " to " + target.name );

		if( target.MyType == Type.Resource && NavAgent.velocity.magnitude < .5 )
		{

			CurrentAction = "Cary " + ResourcesManager.ResourcesNames[ ResourceId ];
			cary = MaxCarry;

			if(NavAgent.remainingDistance < 1 )ResetAnimation( 2 );

		}
		else if( target.MyType == Type.Building )
		{
			if( (target.transform.position - transform.position ).magnitude < Radius )
			{
			ResourcesManager.ResourcesAmount[ ResourceId ] += cary;
			cary = 0;
			CurrentAction = "ReachResource";
			}

		}


	}
}
