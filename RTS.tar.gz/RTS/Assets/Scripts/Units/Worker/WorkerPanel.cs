using UnityEngine;
using System.Collections;
using UnityEngine.UI;


public class WorkerPanel : InteractionPanel 
{
	public Text CurrentState;
	
	void Update () 
	{
		CountPanels();

		if( target != null )
		{
			CurrentState.text = "Worker: " + target.CurrentAction;

		}
	}
}
