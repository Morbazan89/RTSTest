using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class AnimatedUnit : Unit 
{
	public Animator animator;
	public List<string>AnimationNames;
	public List<float> AnimationLengths;
	public int DefaultAnimation;
	public int CurrAnim;
	public float Atention;
	public float AnimationScalar = 1.0f;
	
	public void ResetAnimation( int id )
	{
		if( CurrAnim != id )
		{
		animator.SetBool( AnimationNames[ CurrAnim ], false );
		CurrAnim = id;
		animator.SetBool( AnimationNames[ CurrAnim ], true );
		}
		Atention = AnimationLengths[CurrAnim];


	}

	public void UpdateAnimations()
	{
		if( Atention > 0 )
			Atention -= Time.deltaTime;
		else
			ResetAnimation( DefaultAnimation );

	}

}
