using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class UnitsInteraction : MonoBehaviour 
{
	public static Unit Selected;
	public static Unit Description;
	public InteractionPanel BuildPanel;

	private void Update()
	{
		if( Selected != null && Selected.MyType == Unit.Type.Worker )
		{
			Worker w = Selected.GetComponent<Worker>();

			if( (Time.fixedTime - w.SelectionTime ) < w.ExplicitTaskTimer )
			{



				UIElements.ResetPanel( BuildPanel, w );

			}
			else
				UIElements.ResetPanel(w);

		}

	}
}
