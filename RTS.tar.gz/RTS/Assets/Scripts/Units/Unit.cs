using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class Unit : MonoBehaviour 
{

	public enum Type
	{
		Worker,
		Resource,
		Building,
		BuildManager
	}
	public Type MyType = Type.Resource;
	public string CurrentAction;
	public int Level = 1;
	public int Radius = 10;
	public float SelectionTime = -99999;
	
	private void OnMouseDown()
	{

		UnitsInteraction.Selected = this;
		UIElements.ResetPanel( this );
		SelectionTime = Time.fixedTime;
	
	}

}

