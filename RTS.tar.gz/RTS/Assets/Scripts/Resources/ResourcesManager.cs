using UnityEngine; 
using System.Collections;
using System.Collections.Generic;

public class ResourcesManager : MonoBehaviour 
{
	
	public List<string>	 				resourcesNames;
	public List<ResourceUnit> 			resourceLinks;
	public List<Building>				buildingLinks;
	public List<int>					resourcesAmount;

	public static List<ResourceUnit> 	AllResourceUnits;
	public static List<Building>		AllBuildings;
	public static List<int>				ResourcesAmount;
	public static List<string>			ResourcesNames;

	private void Start()
	{
		AllBuildings = new List<Building>();
		AllResourceUnits = new List<ResourceUnit>();
		ResourcesAmount = new List<int>();
		ResourcesNames = new List<string>();

		foreach( ResourceUnit r in resourceLinks )AllResourceUnits.Add(r);
		foreach( Building b in buildingLinks )AllBuildings.Add(b);
		foreach( string n in resourcesNames )ResourcesNames.Add(n);
		foreach( int a in resourcesAmount )ResourcesAmount.Add(a);
	}

	public static string ConvertRequestToText( List<int> resources )
	{
		string txt = "Requested: \n";
		int numParams = 0;

		for( int i=0; i != resources.Count; i++  )
		{
			if( resources[i] != 0 )
			{
				txt += ResourcesNames[i] + " " + resources[i] + "\n";
				numParams++;
			}
		}

		if( numParams == 0 )txt = "";
		return txt;
	}

	public static bool CanConsume( List< int > amount )
	{

		int miss = 0;
		for( int i=0; i != ResourcesAmount.Count; i++ )
		{
			
			if( ResourcesAmount[i] < amount[i] )miss++;
		}
		
		return miss == 0 ;
	}
	public static bool Consume( List< int > amount )
	{
		int miss = 0;
		for( int i=0; i != ResourcesAmount.Count; i++ )
		{

			if( ResourcesAmount[i] < amount[i] )miss++;
		}

		if(  miss != 0 )return false;

		for( int i=0; i != ResourcesAmount.Count; i++ )
		{
			ResourcesAmount[i] -= amount[i];
		}
		return true;
	}

}
