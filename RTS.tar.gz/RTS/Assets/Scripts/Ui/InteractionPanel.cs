using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class InteractionPanel : MonoBehaviour 
{
	public Unit target;


	public void CountPanels()
	{
	
		RectTransform rect = GetComponent<RectTransform>();

		Vector2 localMouse = rect.InverseTransformPoint( Input.mousePosition );
		if( rect.rect.Contains( localMouse ))
			UIElements.numActivePanels++;
	

	}


	private void Update()
	{
		CountPanels();

	}


	
}
