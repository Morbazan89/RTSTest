using UnityEngine.UI;
using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class ResourcesPanel : MonoBehaviour 
{
	
	public List<Text> ResourcesTexts;

	private void Update()
	{
		for( int i=0; i != ResourcesManager.ResourcesNames.Count; i++ )
			ResourcesTexts[i].text = ResourcesManager.ResourcesNames[i] + " " + ResourcesManager.ResourcesAmount[i];
	}
	
}
