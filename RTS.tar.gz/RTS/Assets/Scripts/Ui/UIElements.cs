using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;

public class UIElements : MonoBehaviour 
{
	public Text SelectedUnit;
	public List<InteractionPanel> interactionPanels;
	public List<Unit.Type> panelTypeLink;

	public static List<InteractionPanel>InteractionPanels = new List<InteractionPanel>();
	public static List<Unit.Type>PanelTypeLink = new List<Unit.Type>();
	public static int numActivePanels = 0;
	public static int prevNumPanels = 0;

	private void Start()
	{
		foreach( InteractionPanel i in interactionPanels)InteractionPanels.Add(i);
		foreach( Unit.Type t in panelTypeLink )PanelTypeLink.Add(t);
	}
	private void LateUpdate()
	{
		prevNumPanels = numActivePanels;
		numActivePanels = 0;
	}
	private void Update()
	{
	
		if( UnitsInteraction.Selected == null )
			SelectedUnit.text = "";
		else
		{
			Unit selected = UnitsInteraction.Selected;

			SelectedUnit.text = UnitsInteraction.Selected.name;

			if( selected.MyType != Unit.Type.Resource )
				SelectedUnit.text += " Level " + selected.Level;
		}
	}
	public static void ResetPanel( Unit u )
	{
		for( int i=0; i != PanelTypeLink.Count; i++ )
		{
			if( u.MyType == PanelTypeLink[i])
			{
				InteractionPanels[i].gameObject.SetActive( true  );
				InteractionPanels[i].target = u;
			}
			else
				InteractionPanels[i].gameObject.SetActive( false  );
		}
	}
	public static void ResetPanel( InteractionPanel panel, Unit u )
	{
		for( int i=0; i != InteractionPanels.Count; i++ )
		{
			if( panel == InteractionPanels[i] )
			{
				InteractionPanels[i].gameObject.SetActive( true  );
				InteractionPanels[i].target = u;
			}
			else
				InteractionPanels[i].gameObject.SetActive( false  );
		}
	}
	public static void HideInteractionPanels()
	{
		for( int i=0; i != InteractionPanels.Count; i++ )
			InteractionPanels[i].gameObject.SetActive( false );
	}
}
